#define U_BOOT_DATE "Nov 30 2012"
#define U_BOOT_TIME "01:36:04"
